from django.contrib import admin

from .models import DatosCliendo

admin.site.register(DatosCliendo)
