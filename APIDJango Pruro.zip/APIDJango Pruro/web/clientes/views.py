#from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from .models import DatosCliendo
from django.forms.models import model_to_dict


#Envia el formulario Serializado en formato JSon
class FormularioView(View):
      #Metodo sobreescrito de View
      def get(self,request):
            lista = DatosCliendo.objects.all()
            return JsonResponse(list(lista.values()),safe=False)
            
#Envia el formulario Serializado en formato JSon
class FormularioEscojidoView(View):
      #Metodo sobreescrito de View
      def get(self,request,indice):
            
            dato = DatosCliendo.objects.get(pk=indice)
            return JsonResponse(model_to_dict(dato))
            


