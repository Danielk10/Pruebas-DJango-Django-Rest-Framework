from django.urls import path
from .views import FormularioEscojidoView, FormularioView


urlpatterns = [
    path('formulario/', FormularioView.as_view(),name='lista'),
    path('formulariovarios/<int:indice>/', FormularioEscojidoView.as_view(),name='dato'),
]