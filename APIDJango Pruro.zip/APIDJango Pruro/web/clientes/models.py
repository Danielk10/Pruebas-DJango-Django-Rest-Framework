from django.db import models

class DatosCliendo(models.Model):
    nombre = models.CharField(max_length=20)
    apellido = models.CharField(max_length=50)
    edad = models.CharField(max_length=10)



