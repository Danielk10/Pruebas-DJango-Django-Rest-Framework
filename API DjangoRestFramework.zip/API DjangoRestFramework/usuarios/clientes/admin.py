from django.contrib import admin

#registrando mi modelo
from .models import DatosUsuarios

admin.site.register(DatosUsuarios)
