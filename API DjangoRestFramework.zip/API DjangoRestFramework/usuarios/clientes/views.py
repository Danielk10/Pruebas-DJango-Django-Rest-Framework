#from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import PruebaSerializarJson

class PruebaParaMiView(APIView):

    selizador = PruebaSerializarJson()
    #Sobrescribiendo metodo
    def get(this,request,format=None):

        


        vista_api = [ 'Hola API rest de Django',
        'Primera prueba',
        
        
        ]

        return Response({'mensaje':'hola','api':vista_api}) # un hashMap

    #Sobrescribiendo metodo
    def post(this,request):

        serilador_tem = this.selizador(data = request.data)

        if serilador_tem.is_valid():

            nombre = serilador_tem.validated_data.get('nombre')

            mensaje =f"hola {nombre}"

            return Response({'mensaje':mensaje})

        else:

            return Response(serilador_tem.errors,status = status.HTTP_400_BAD_REQUEST)





