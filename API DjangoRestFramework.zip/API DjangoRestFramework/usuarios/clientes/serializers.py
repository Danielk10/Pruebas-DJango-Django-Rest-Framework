from rest_framework import serializers
from rest_framework.serializers import Serializer


#Prueba de serializacion
class PruebaSerializarJson(Serializer):

    nombre = serializers.CharField(max_length =10)



