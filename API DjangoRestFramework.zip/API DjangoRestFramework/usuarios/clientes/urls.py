from django.urls import path
from .views import PruebaParaMiView


urlpatterns = [
    path('api/', PruebaParaMiView.as_view(), name='datos'),
]