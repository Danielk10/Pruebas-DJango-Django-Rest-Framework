from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager, User
from django.db.models.fields import BooleanField


#Creando mi manejador de usuarios 
class ManejadorDatosUsuarios(BaseUserManager):

    #Sobreescribiendo metodo
    def create_user(this,correo,nombre,contracena =None):

        if not correo:
            e = ValueError("El usuario debe tener correo")
        
        correo = this.normalize_email(correo)

        usuario = this.model(correo = correo,nombre = nombre)
        
        usuario.set_password(contracena)
        
        usuario.save(using = this.db)

        return usuario

     #Sobreescribiendo metodo
    def create_superuser(this,correo,nombre,password):

        usuario = this.create_user(correo,nombre,password)

        usuario.is_superuser = True

        usuario.miembro_equipo = True

        usuario.save(using = this.db)

        return usuario


#Creando un modelo personalizado, Crea los datos de los usuarios en la BD
class DatosUsuarios(AbstractBaseUser,PermissionsMixin):

    correo = models.EmailField(max_length=50,unique = True)

    nombre = models.CharField(max_length=50)

    usuario_activo = models.BooleanField(default=True)

    is_staff = models,BooleanField(default=False)

    mi_objeto = ManejadorDatosUsuarios()

    USERNAME_FIELD = 'correo'
 
    REQUIRED_FIELDS = ['nombre']

    def get_nombre_completo(this):

        return this.nombre

    def get_nombre(this):
        
        return this.nombre
    #Sobreescribiendo metodo
    def __str__(self):

        return self.correo
    
        


